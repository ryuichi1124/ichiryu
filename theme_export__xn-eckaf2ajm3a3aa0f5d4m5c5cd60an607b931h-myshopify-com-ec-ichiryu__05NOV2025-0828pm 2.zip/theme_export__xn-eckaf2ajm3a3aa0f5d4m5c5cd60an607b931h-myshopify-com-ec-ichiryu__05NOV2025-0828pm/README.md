# イチリュウ クリスマスケーキ予約サイト Shopifyテーマ

このリポジトリは、イチリュウのクリスマスケーキ予約サイト用のShopifyテーマです。

## 概要

- **テーマ名**: Dawn (カスタマイズ版)
- **対象サイト**: イチリュウ クリスマスケーキ予約サイト
- **カスタマイズ日**: 2025年11月

## 主なカスタマイズ内容

### 1. クリスマステーマカスタマイズ
- クリスマスカラーパレットの適用
- カスタムフォント（Playfair Display, Montserrat）の統合
- クリスマスバッジの追加（「事前予約特典」など）

### 2. 画像の組み込み
- **ヒーローバナー画像**: イチリュウクリスマスケーキのヒーロー画像をデフォルトとして設定
- **ロゴ画像**: 白文字/黒文字のロゴを動的に切り替え可能

### 3. カスタムスニペット
- `ichiryu-logo.liquid`: イチリュウロゴの表示用スニペット
- `christmas-badge.liquid`: クリスマスバッジ表示用スニペット

### 4. カスタムCSS
- `assets/christmas-theme.css`: クリスマステーマ用のカスタムスタイル

## ファイル構成

```
theme_export__xn-eckaf2ajm3a3aa0f5d4m5c5cd60an607b931h-myshopify-com-ec-ichiryu__05NOV2025-0828pm/
├── assets/
│   └── christmas-theme.css          # クリスマステーマ用CSS
├── config/
│   ├── settings_data.json
│   └── settings_schema.json
├── layout/
│   └── theme.liquid                 # メインレイアウト（Google Fonts統合）
├── sections/
│   ├── header.liquid                 # ヘッダー（ロゴ統合）
│   └── image-banner.liquid           # ヒーローバナー（画像統合）
├── snippets/
│   ├── ichiryu-logo.liquid          # イチリュウロゴスニペット
│   └── christmas-badge.liquid       # クリスマスバッジスニペット
├── templates/
└── locales/
```

## 使用方法

### Shopifyへのアップロード

1. このディレクトリをZIPファイルに圧縮
2. Shopify管理画面 > オンラインストア > テーマ > カスタマイズ > テーマライブラリ
3. 「アップロード」をクリックしてZIPファイルをアップロード

### カスタマイズ詳細

詳細は `ICHIRYU_CUSTOMIZATION_SUMMARY.md` を参照してください。

## 画像URL

- **ヒーローバナー**: `https://cdn.shopify.com/s/files/1/0968/0689/5928/files/ichiryu_Xmas_H1_HI.jpg?v=1762394313`
- **ロゴ（白文字）**: `https://cdn.shopify.com/s/files/1/0968/0689/5928/files/ichiryulogod.png?v=1762394601`
- **ロゴ（黒文字）**: `https://cdn.shopify.com/s/files/1/0968/0689/5928/files/ichiryulogod2.png?v=1762394602`

## ライセンス

このテーマはShopifyのDawnテーマをベースにしています。

## 更新履歴

- **2025-11-06**: 初期カスタマイズ完了
  - クリスマステーマの適用
  - ヒーローバナー画像の統合
  - ロゴ画像の統合
  - カスタムCSSの追加

